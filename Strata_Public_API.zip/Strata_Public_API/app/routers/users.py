from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.user import User, UserUpdate

router = APIRouter(
    prefix="/users",
    tags=["Users"],
)

@router.post("/", response_model=User, status_code=status.HTTP_201_CREATED, summary="Create User", description="Registers a new user in the system, assigning them a user type and initial status.")
async def create_user(user: User):
    """
    Create a new User.
    """
    print(f"Creating User: {user.email}")
    return user

@router.get("/", response_model=List[User], summary="Get All Users", description="Retrieves a list of all registered users in the system.")
async def get_all_users():
    """
    Retrieve all Users.
    """
    return []

@router.get("/{user_id}", response_model=User, summary="Get User by ID", description="Fetches the detailed profile information for a specific user using their unique ID.")
async def get_user(user_id: str):
    """
    Retrieve a specific User by their ID.
    """
    raise HTTPException(status_code=404, detail=f"User {user_id} not found")

@router.patch("/{user_id}", response_model=User, summary="Update User", description="Modifies the details of an existing user, such as name, email, or status.")
async def update_user(user_id: str, user_update: UserUpdate):
    """
    Update a User's details.
    """
    raise HTTPException(status_code=404, detail=f"User {user_id} not found")

@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete User", description="Removes a user record from the system based on their unique ID.")
async def delete_user(user_id: str):
    """
    Delete a User.
    """
    print(f"Deleting User: {user_id}")
    return