from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.currency import Currency, CurrencyUpdate

router = APIRouter(
    prefix="/currencies",
    tags=["Currencies"],
)

@router.post("/", response_model=Currency, status_code=status.HTTP_201_CREATED, summary="Create Currency", description="Adds a new currency definition to the system, specifying its ISO code, name, and creation timestamp.")
async def create_currency(currency: Currency):
    """
    Create a new Currency.
    """
    print(f"Creating Currency: {currency.isoCode} - {currency.name}")
    return currency

@router.get("/", response_model=List[Currency], summary="Get All Currencies", description="Retrieves a list of all defined currencies.")
async def get_all_currencies():
    """
    Retrieve all Currencies.
    """
    return []

@router.get("/{iso_code}", response_model=Currency, summary="Get Currency by ISO Code", description="Fetches the details of a specific currency using its unique ISO code.")
async def get_currency(iso_code: str):
    """
    Retrieve a specific Currency by its ISO code.
    """
    raise HTTPException(status_code=404, detail=f"Currency with ISO code {iso_code} not found")

@router.patch("/{iso_code}", response_model=Currency, summary="Update Currency", description="Modifies the name of an existing currency based on its ISO code.")
async def update_currency(iso_code: str, currency_update: CurrencyUpdate):
    """
    Update a Currency's details.
    """
    raise HTTPException(status_code=404, detail=f"Currency with ISO code {iso_code} not found")

@router.delete("/{iso_code}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete Currency", description="Removes a currency definition from the system based on its unique ISO code.")
async def delete_currency(iso_code: str):
    """
    Delete a Currency.
    """
    print(f"Deleting Currency: {iso_code}")
    return