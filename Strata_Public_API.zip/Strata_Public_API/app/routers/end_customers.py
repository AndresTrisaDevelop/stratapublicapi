from fastapi import APIRouter, HTTPException, status
from typing import List
from ..schemas.end_customer import EndCustomer, EndCustomerUpdate

router = APIRouter(
    prefix="/end-customers",
    tags=["End Customers"],
)

@router.post("/", response_model=EndCustomer, status_code=status.HTTP_201_CREATED, summary="Create End Customer", description="Registers a new end customer in the system with their contact and identification details.")
async def create_end_customer(customer: EndCustomer):
    """
    Create a new End Customer.
    """
    print(f"Creating End Customer: {customer.name}")
    return customer

@router.get("/", response_model=List[EndCustomer], summary="Get All End Customers", description="Retrieves a comprehensive list of all registered end customers, including their details.")
async def get_all_end_customers():
    """
    Retrieve all End Customers.
    """
    return []

@router.get("/{customer_id}", response_model=EndCustomer, summary="Get End Customer by ID", description="Fetches the detailed information for a single end customer using their unique identifier.")
async def get_end_customer(customer_id: str):
    """
    Retrieve a specific End Customer by its ID.
    """
    raise HTTPException(status_code=404, detail=f"Customer {customer_id} not found")

@router.patch("/{customer_id}", response_model=EndCustomer, summary="Update End Customer", description="Modifies the existing details of an end customer identified by their unique ID.")
async def update_end_customer(customer_id: str, customer_update: EndCustomerUpdate):
    """
    Update an End Customer.
    """
    raise HTTPException(status_code=404, detail=f"Customer {customer_id} not found")

@router.delete("/{customer_id}", status_code=status.HTTP_204_NO_CONTENT, summary="Delete End Customer", description="Removes an end customer record from the system based on their unique identifier.")
async def delete_end_customer(customer_id: str):
    """
    Delete an End Customer.
    """
    print(f"Deleting End Customer: {customer_id}")
    return