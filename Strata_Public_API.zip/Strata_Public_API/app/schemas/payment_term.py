from pydantic import BaseModel, Field
from typing import Optional

class PaymentTerm(BaseModel):
    termId: str = Field(..., description="Unique identifier for the payment term, e.g., 'NET30'")
    description: str = Field(..., description="Description of the payment term, e.g., 'Net 30 Days'")
    dueDays: int = Field(..., description="Number of days until payment is due")

class PaymentTermUpdate(BaseModel):
    description: Optional[str] = None
    dueDays: Optional[int] = None