from pydantic import BaseModel, Field
from typing import Optional

class EndCustomer(BaseModel):
    customerId: str = Field(..., description="Unique identifier for the end customer")
    name: str = Field(..., description="Name of the end customer")
    address: Optional[str] = None
    primaryContactName: Optional[str] = None
    email: Optional[str] = Field(None, format="email")
    phone: Optional[str] = None

class EndCustomerUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    primaryContactName: Optional[str] = None
    email: Optional[str] = Field(None, format="email")
    phone: Optional[str] = None