from pydantic import BaseModel, Field
from typing import Optional

class TaxGroup(BaseModel):
    taxGroupId: str = Field(..., description="Unique identifier for the tax group, e.g., 'VAT-21'")
    name: str = Field(..., description="Name of the tax group, e.g., 'Value Added Tax 21%'")
    rate: float = Field(..., description="Tax rate as a percentage, e.g., 21.0")
    isDefault: Optional[bool] = False

class TaxGroupUpdate(BaseModel):
    name: Optional[str] = None
    rate: Optional[float] = None
    isDefault: Optional[bool] = None