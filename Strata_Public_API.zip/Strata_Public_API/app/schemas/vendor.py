from pydantic import BaseModel, Field
from typing import Optional

class Vendor(BaseModel):
    vendorId: str = Field(..., description="Unique identifier for the vendor")
    name: str = Field(..., description="Name of the vendor")
    address: Optional[str] = None
    primaryContactName: Optional[str] = None
    email: Optional[str] = Field(None, format="email")
    phone: Optional[str] = None
    taxId: Optional[str] = None

class VendorUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    primaryContactName: Optional[str] = None
    email: Optional[str] = Field(None, format="email")
    phone: Optional[str] = None
    taxId: Optional[str] = None