from pydantic import BaseModel, Field
from typing import List, Optional, Any
from datetime import date, datetime

# Re-using LineItem from purchase_order for consistency
from .purchase_order import LineItem

class Identifiers(BaseModel):
    invoiceNumber: Optional[str] = None
    invoiceDate: Optional[date] = None
    poNumber: Optional[str] = None
    poDate: Optional[date] = None
    quoteNumber: Optional[str] = None
    universalNumber: Optional[str] = None
    batchNumber: Optional[str] = None
    batchNameMigrated: Optional[str] = None
    invoiceType: Optional[str] = None
    invoiceTotal: Optional[float] = None
    poTotal: Optional[float] = None

class Vendor(BaseModel):
    vendorId: Optional[str] = None
    vendorName: Optional[str] = None
    vendorInternalNumber: Optional[str] = None
    vendorPoNumber: Optional[str] = None
    vendorSalesOrderNumber: Optional[str] = None

class ContactAndEmails(BaseModel):
    emailFrom: Optional[str] = None
    emailTo: Optional[str] = None
    emailSubject: Optional[str] = None
    customerEmail: Optional[str] = None
    dealerPhone1: Optional[str] = None

class Dates(BaseModel):
    processedOn: Optional[datetime] = None
    clientProcessedOn: Optional[datetime] = None
    dateCapturedMigrated: Optional[datetime] = None
    migratedDateCaptured: Optional[str] = None
    indexDateMigrated: Optional[date] = None
    lastRunDateTime: Optional[str] = None
    datePaid: Optional[date] = None
    shipDate: Optional[date] = None

class Financials(BaseModel):
    invoiceTotal: Optional[float] = None
    balanceDue: Optional[float] = None
    discountAmount: Optional[float] = None
    discountTerms: Optional[str] = None
    discountDueDate: Optional[date] = None
    depositAmount: Optional[float] = None
    freight: Optional[float] = None
    freight2: Optional[float] = None
    productSubtotal: Optional[float] = None
    salesTax: Optional[float] = None
    surcharge: Optional[float] = None
    tariff: Optional[float] = None
    totalGrossProfit: Optional[float] = None
    totalSaleAmount: Optional[float] = None
    grossMarginPercent: Optional[str] = None

class Project(BaseModel):
    projectId: Optional[str] = None
    projectName: Optional[str] = None
    projectManager: Optional[str] = None
    projectPhase: Optional[str] = None
    projectStatus: Optional[str] = None
    projectSubType: Optional[str] = None
    projectSiteId: Optional[str] = None
    projectCapitalDriver: Optional[str] = None

class LocationAndProperty(BaseModel):
    location: Optional[str] = None
    installationAddress: Optional[str] = None
    propertyAddress: Optional[str] = None
    floorNumber: Optional[str] = None
    facilityPartner: Optional[str] = None
    fobTerm: Optional[str] = None
    shippingMethod: Optional[str] = None
    shipmentNumber: Optional[str] = None

class ApprovalsAndWorkflow(BaseModel):
    approverNotificationState: Optional[str] = None
    pjmApproval: Optional[str] = None
    pjmRejectionAdditionalComments: Optional[str] = None
    pjmRejectionReasons: Optional[List[str]] = None
    fasObComments: Optional[str] = None
    fasObReviewReasons: Optional[List[str]] = None
    fasObTrackingStatus: Optional[str] = None
    problemCode: Optional[str] = None
    problemCodeMigrated: Optional[str] = None

class ErrorsAndMigration(BaseModel):
    errorDescription: Optional[str] = None
    errorTracking: Optional[List[str]] = None
    itemHashMigrated: Optional[str] = None
    itemIdMigrated: Optional[str] = None
    hashSignatureMigrated: Optional[str] = None
    filenameMigrated: Optional[str] = None
    originalFileNameMigrated: Optional[str] = None
    migratedTenantName: Optional[str] = None
    internalRecordIdMigrated: Optional[str] = None
    indexDateMigratedString: Optional[str] = None
    invalidDates: Optional[str] = None
    pageCountMigrated: Optional[int] = None
    viewLinkMigrated: Optional[str] = None

class Assignment(BaseModel):
    assignedTo: Optional[str] = None
    assignedToMigrated: Optional[str] = None
    assignedDepartmentMigrated: Optional[str] = None
    manualAssignedDepartment: Optional[str] = None
    manualAssignedTo: Optional[str] = None

class Processing(BaseModel):
    processName: Optional[str] = None
    processingInstructions: Optional[str] = None
    processingComments: Optional[str] = None
    recordStatus: Optional[str] = None
    statusMigrated: Optional[str] = None

class Audit(BaseModel):
    acComments: Optional[str] = None
    apComments: Optional[str] = None
    apRepresentative: Optional[str] = None
    manualApproverName: Optional[str] = None
    salesPerson: Optional[str] = None
    capitalManager: Optional[str] = None

class Additional(BaseModel):
    addresses: Optional[Any] = None
    attachment: Optional[Any] = None
    manufacturer: Optional[str] = None
    endCustomerName: Optional[str] = None
    endUserPo: Optional[str] = None
    contractNumber: Optional[str] = None
    contractName: Optional[str] = None
    packageComplete: Optional[str] = None
    pageCountMigrated: Optional[int] = None
    trackingNumber: Optional[str] = None
    shipmentNumber: Optional[str] = None

class Bill(BaseModel):
    identifiers: Optional[Identifiers] = None
    vendor: Optional[Vendor] = None
    contactAndEmails: Optional[ContactAndEmails] = None
    dates: Optional[Dates] = None
    financials: Optional[Financials] = None
    project: Optional[Project] = None
    locationAndProperty: Optional[LocationAndProperty] = None
    approvalsAndWorkflow: Optional[ApprovalsAndWorkflow] = None
    errorsAndMigration: Optional[ErrorsAndMigration] = None
    assignment: Optional[Assignment] = None
    processing: Optional[Processing] = None
    lineItems: Optional[List[LineItem]] = None
    audit: Optional[Audit] = None
    additional: Optional[Additional] = None

class BillUpdate(BaseModel):
    identifiers: Optional[Identifiers] = None
    vendor: Optional[Vendor] = None
    contactAndEmails: Optional[ContactAndEmails] = None
    dates: Optional[Dates] = None
    financials: Optional[Financials] = None
    project: Optional[Project] = None
    locationAndProperty: Optional[LocationAndProperty] = None
    approvalsAndWorkflow: Optional[ApprovalsAndWorkflow] = None
    errorsAndMigration: Optional[ErrorsAndMigration] = None
    assignment: Optional[Assignment] = None
    processing: Optional[Processing] = None
    lineItems: Optional[List[LineItem]] = None
    audit: Optional[Audit] = None
    additional: Optional[Additional] = None
