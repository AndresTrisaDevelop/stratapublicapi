from pydantic import BaseModel, Field
from typing import Optional

class Dealer(BaseModel):
    dealerId: str = Field(..., description="Unique identifier for the dealer")
    name: str = Field(..., description="Name of the dealer")
    address: Optional[str] = None
    primaryContactName: Optional[str] = None
    email: Optional[str] = Field(None, format="email")
    phone: Optional[str] = None

class DealerUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    primaryContactName: Optional[str] = None
    email: Optional[str] = Field(None, format="email")
    phone: Optional[str] = None