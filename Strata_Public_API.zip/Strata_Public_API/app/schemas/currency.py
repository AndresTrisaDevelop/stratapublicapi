from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class Currency(BaseModel):
    isoCode: str = Field(..., description="The 3-letter ISO 4217 code for the currency.", max_length=3, min_length=3)
    name: str = Field(..., description="The full name of the currency.")
    createdAt: datetime = Field(default_factory=datetime.utcnow, description="Timestamp when the currency was created")

class CurrencyUpdate(BaseModel):
    name: Optional[str] = None