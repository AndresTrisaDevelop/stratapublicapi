from pydantic import BaseModel, Field
from typing import List, Optional, Any
from datetime import date, datetime

# Re-using LineItem from purchase_order for consistency
from .purchase_order import LineItem

class AckInfo(BaseModel):
    acknowledgementNumber: str = Field(..., description="Acknowledgement Number")
    acknowledgementDate: date = Field(..., description="Acknowledgement Date")
    acknowledgedShipDate: Optional[date] = None
    acknowledgementTotal: Optional[float] = None
    actionableDate: Optional[date] = None
    arrivalDate: Optional[date] = None
    confirmedInstallDate: Optional[date] = None
    poIssueDate: Optional[date] = None
    poNumber: Optional[str] = None
    orderDate: Optional[datetime] = None
    orderNumber: Optional[str] = None

class VendorAndBillTo(BaseModel):
    billToAddress: Optional[str] = None
    billToName: Optional[str] = None
    dealerName: Optional[str] = None
    dealerOrderNumber: Optional[str] = None
    dealerOrderDate: Optional[date] = None
    dealerShipToAddress: Optional[str] = None
    dealerStatus: Optional[str] = None
    dealerNotificationDate: Optional[datetime] = None

class ContactAndEmails(BaseModel):
    emailFrom: Optional[str] = None
    emailTo: Optional[str] = None
    emailSubject: Optional[str] = None
    clientContact: Optional[str] = None
    endUserShipTo: Optional[str] = None

class DatesAndFlags(BaseModel):
    created: Optional[date] = None
    createdCapturedMigrated: Optional[datetime] = None
    dateInfoRecvd: Optional[date] = None
    indexDateMigrated: Optional[date] = None
    pageCountMigrated: Optional[int] = None
    closed: Optional[date] = None
    closedBy: Optional[str] = None

class ProductAndFurniture(BaseModel):
    productDescription: Optional[str] = None
    productSubtotal: Optional[float] = None
    furnitureCategory: Optional[str] = None
    furnitureSubCategory: Optional[str] = None
    furnitureRequired: Optional[str] = None
    furnitureOrderStatus: Optional[str] = None

class Processing(BaseModel):
    processName: Optional[str] = None
    processedOn: Optional[datetime] = None
    problemCode: Optional[str] = None
    problemCodeMigrated: Optional[str] = None
    processingInstructions: Optional[str] = None
    priority: Optional[str] = None
    requestType: Optional[str] = None
    requestDate: Optional[date] = None

class Assignment(BaseModel):
    assignedTo: Optional[str] = None
    assignedToMigrated: Optional[str] = None
    assignedProcurement: Optional[str] = None
    assignedDepartmentMigrated: Optional[str] = None
    manualAssignedTo: Optional[str] = None

class ErrorsAndMigration(BaseModel):
    errorDescription: Optional[str] = None
    errorTracking: Optional[List[str]] = None
    itemHashMigrated: Optional[str] = None
    itemIdMigrated: Optional[str] = None
    hashSignatureMigrated: Optional[str] = None
    filenameMigrated: Optional[str] = None
    originalFileNameMigrated: Optional[str] = None

class LocationAndShipping(BaseModel):
    location: Optional[str] = None
    locationType: Optional[str] = None
    installationAddress: Optional[str] = None
    installComplete: Optional[str] = None
    installer: Optional[str] = None
    shipDate: Optional[date] = None
    shipToCityState: Optional[str] = None
    shipToName: Optional[str] = None
    freight: Optional[float] = None
    freight2: Optional[float] = None

class ApprovalsAndNotes(BaseModel):
    additionalAgentNotes: Optional[str] = None
    additionalComments: Optional[str] = None
    notes: Optional[str] = None
    notes2: Optional[str] = None
    acComments: Optional[str] = None

class AckLineItemOptions(BaseModel):
    optionNumber: Optional[str] = None
    optionGroup: Optional[str] = None
    optionDescription: Optional[str] = None

class AckLineItem(BaseModel):
    productNumber: str
    catalogCode: Optional[str] = None
    description: Optional[str] = None
    quantity: Optional[float] = None
    productCost: Optional[float] = None
    productList: Optional[float] = None
    productSell: Optional[float] = None
    purchaseDiscount: Optional[float] = None
    totalList: Optional[float] = None
    totalProduct: Optional[float] = None
    options: Optional[List[AckLineItemOptions]] = None
    productSubtotal: Optional[float] = None

class Acknowledgement(BaseModel):
    ackInfo: AckInfo
    vendorAndBillTo: Optional[VendorAndBillTo] = None
    contactAndEmails: Optional[ContactAndEmails] = None
    datesAndFlags: Optional[DatesAndFlags] = None
    productAndFurniture: Optional[ProductAndFurniture] = None
    processing: Optional[Processing] = None
    assignment: Optional[Assignment] = None
    errorsAndMigration: Optional[ErrorsAndMigration] = None
    locationAndShipping: Optional[LocationAndShipping] = None
    approvalsAndNotes: Optional[ApprovalsAndNotes] = None
    lineItems: Optional[List[AckLineItem]] = None

class AcknowledgementUpdate(BaseModel):
    ackInfo: Optional[AckInfo] = None
    vendorAndBillTo: Optional[VendorAndBillTo] = None
    contactAndEmails: Optional[ContactAndEmails] = None
    datesAndFlags: Optional[DatesAndFlags] = None
    productAndFurniture: Optional[ProductAndFurniture] = None
    processing: Optional[Processing] = None
    assignment: Optional[Assignment] = None
    errorsAndMigration: Optional[ErrorsAndMigration] = None
    locationAndShipping: Optional[LocationAndShipping] = None
    approvalsAndNotes: Optional[ApprovalsAndNotes] = None
    lineItems: Optional[List[AckLineItem]] = None