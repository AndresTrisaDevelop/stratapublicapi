from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import date, datetime

class InvoiceIdentifiers(BaseModel):
    invoiceNumber: str = Field(..., description="Invoice Number")
    invoiceDate: date = Field(..., description="Invoice Date")
    invoiceTotal: float = Field(..., description="Invoice Total (currency)")
    balanceDue: Optional[float] = None
    dueDate: Optional[date] = None

class Customer(BaseModel):
    customerId: Optional[str] = None
    customerName: Optional[str] = None
    customerEmail: Optional[str] = None
    customerPoDate: Optional[date] = None
    customerPurchaseOrder: Optional[str] = None

class ContactAndEmail(BaseModel):
    emailSubject: Optional[str] = None
    emailTo: Optional[str] = None
    emailComments: Optional[str] = None

class DatesAndMigration(BaseModel):
    dateCapturedMigrated: Optional[datetime] = None
    indexDateMigrated: Optional[date] = None
    originalFileNameMigrated: Optional[str] = None
    itemIdMigrated: Optional[str] = None

class Document(BaseModel):
    description: Optional[str] = None
    documentAge: Optional[str] = None
    postingPeriod: Optional[str] = None
    pageCountMigrated: Optional[int] = None

class LocationAndStatus(BaseModel):
    location: Optional[str] = None
    notificationState: Optional[str] = None
    recordStatus: Optional[str] = None
    nextFollowUp: Optional[date] = None

class Process(BaseModel):
    processName: Optional[str] = None
    processedOn: Optional[datetime] = None

class Errors(BaseModel):
    errorTracking: Optional[List[str]] = None
    comments: Optional[str] = None

class SalesAndOrders(BaseModel):
    salesPerson: Optional[str] = None
    salesOrderNumber: Optional[str] = None
    shipDate: Optional[date] = None
    terms: Optional[str] = None
    units: Optional[str] = None
    commissionCode: Optional[str] = None

class CustomerInvoice(BaseModel):
    invoiceIdentifiers: InvoiceIdentifiers
    customer: Customer
    contactAndEmail: Optional[ContactAndEmail] = None
    datesAndMigration: Optional[DatesAndMigration] = None
    document: Optional[Document] = None
    locationAndStatus: Optional[LocationAndStatus] = None
    process: Optional[Process] = None
    errors: Optional[Errors] = None
    salesAndOrders: Optional[SalesAndOrders] = None

class CustomerInvoiceUpdate(BaseModel):
    invoiceIdentifiers: Optional[InvoiceIdentifiers] = None
    customer: Optional[Customer] = None
    contactAndEmail: Optional[ContactAndEmail] = None
    datesAndMigration: Optional[DatesAndMigration] = None
    document: Optional[Document] = None
    locationAndStatus: Optional[LocationAndStatus] = None
    process: Optional[Process] = None
    errors: Optional[Errors] = None
    salesAndOrders: Optional[SalesAndOrders] = None