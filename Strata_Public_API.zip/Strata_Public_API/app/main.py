from fastapi import FastAPI
from .routers import (
    accounts_payable,
    accounts_receivable,
    configuration,
    vendors,
    dealers,
    payment_terms,
    end_customers,
    users,
    catalogs,
    currencies,
)

app = FastAPI(
    title="Strata Public API",
    description="API for managing transactional information in the furniture industry.",
    version="1.0.0",
)

# Incluir los routers en la aplicación principal
app.include_router(accounts_payable.router)
app.include_router(accounts_receivable.router)
app.include_router(configuration.router)
app.include_router(vendors.router)
app.include_router(dealers.router)
app.include_router(payment_terms.router)
app.include_router(end_customers.router)
app.include_router(users.router)
app.include_router(catalogs.router)
app.include_router(currencies.router)

@app.get("/", tags=["Root"])
async def read_root():
    """
    Root endpoint of the Strata API.
    """
    return {"message": "Welcome to the Strata Public API"}
